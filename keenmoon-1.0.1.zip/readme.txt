=== KeenMoon Theme ===
Contributors: shafiqul
Requires at least: WordPress 4.5
Tested up to: WordPress 4.5-trunk
Version: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: pink, black, blue, gray, red, white, yellow, dark, light, left-sidebar, right-sidebar, fixed-layout, fluid-layout, responsive-layout, accessibility-ready, custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-images, flexible-header, microformats, post-formats, rtl-language-support, threaded-comments, translation-ready

== Description ==
keenmoon theme can be used for newspaper, publishing, personal and corporate blogs. keenmoon is the free and paid version of the professional wordpress blog theme. The Theme has been responsive layout and simple layout. This theme is a SEO friendly.  You can  easylly change color, menu color, primary color, hover color, Category color, header options, header logo upload, sticky menu, footer option etc.


== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in KeenMoon in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
4. Navigate to Appearance > Customize in your admin panel and customize to taste.


== Changelog ==

= 1.0.1 =
* Released: August 4, 2016
* Change Some Code.

= 1.0 =
* Released: May 1, 2016

Initial release
